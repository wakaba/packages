package Test::Dongry::Query1;
use strict;
use warnings;
use base qw(Dongry::Query);

sub table_name {
  return 'table1';
} # table_name

1;
